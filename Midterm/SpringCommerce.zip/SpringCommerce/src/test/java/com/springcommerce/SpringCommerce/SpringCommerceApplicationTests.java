package com.springcommerce.SpringCommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCommerceApplicationTests {

	@Test
	void contextLoads() {
	}

}
